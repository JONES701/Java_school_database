package my;

public interface Details {

    int marks1=10;
    int marks2 =8;

    String student1="Rohan";
    String student2="Myra";

    String address1="2/4 nivihar ganges road 411002";
    String address2="1/2 mir apartment ganges road 411002";

    String dob1="30/01/2000";
    String dob2="23/05/1978";


    String teacher1="Priya Salunke";
    String teacher2="Meenakshi Bhatt";

}
